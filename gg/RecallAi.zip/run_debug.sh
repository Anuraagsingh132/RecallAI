#!/bin/bash
#
# RecallAI Debug Script
# This script starts the RecallAI in debug mode with full console output.
#

# Call the main script with the debug flag
./run_app.sh --debug 